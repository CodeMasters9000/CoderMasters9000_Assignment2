/**
 * 
 */
package controller;

import org.springframework.stereotype.Controller;

/**
 * @author Parham
 *
 */

@Controller
public class Com_Controller {

}
